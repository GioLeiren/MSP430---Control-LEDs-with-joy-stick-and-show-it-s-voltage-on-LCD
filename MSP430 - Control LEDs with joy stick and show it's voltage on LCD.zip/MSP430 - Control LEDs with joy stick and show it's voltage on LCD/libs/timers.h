#ifndef __TIMERS_H
#define __TIMERS_H
#include <stdint.h>

void timerConfig(void);

#endif
