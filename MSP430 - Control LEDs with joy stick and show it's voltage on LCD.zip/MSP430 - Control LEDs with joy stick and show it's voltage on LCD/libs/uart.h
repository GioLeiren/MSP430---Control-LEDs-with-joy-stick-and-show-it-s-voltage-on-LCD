#ifndef __UART_H
#define __UART_H
#include <stdint.h>

void uartInit(void);
uint8_t uartReceive();


#endif
