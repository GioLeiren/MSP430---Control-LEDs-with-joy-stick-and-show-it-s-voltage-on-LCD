#ifndef __ADC_H
#define __ADC_H
#include <stdint.h>

float analogReadx(uint8_t pinx);
float analogReady(uint8_t piny);


#endif
